package com.lankacraft.lankacraft;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LankacraftApplicationTests {

	@Test
	void contextLoads() {
	}

}
